#include<immintrin.h>
const char* dgemv_desc = "Vectorized implementation of matrix-vector multiply.";

/*
 * This routine performs a dgemv operation
 * Y :=  A * X + Y
 * where A is n-by-n matrix stored in row-major format, and X and Y are n by 1 vectors.
 * On exit, A and X maintain their input values.
 */
void my_dgemv(int n, double* A, double* x, double* y) {
   // insert your code here: implementation of vectorized vector-matrix multiply
   // Vectorize the matrix-vector multiplication loop
    for (int i = 0; i < n; ++i) {
        __m256d ymm_sum = _mm256_setzero_pd();
        for (int j = 0; j < n; j += 4) {
            __m256d ymm_a = _mm256_loadu_pd(&A[i * n + j]);
            __m256d ymm_x = _mm256_loadu_pd(&x[j]);
            ymm_sum = _mm256_add_pd(ymm_sum, _mm256_mul_pd(ymm_a, ymm_x));
        }
        // Horizontal sum of the four elements in ymm_sum
        __m128d xmm_sum_hi = _mm256_extractf128_pd(ymm_sum, 1);
        __m128d xmm_sum_lo = _mm256_castpd256_pd128(ymm_sum);
        xmm_sum_lo = _mm_add_pd(xmm_sum_lo, xmm_sum_hi);
        xmm_sum_lo = _mm_hadd_pd(xmm_sum_lo, xmm_sum_lo);
        y[i] += _mm_cvtsd_f64(xmm_sum_lo);
    }
}
